//引入
import {list,add} from "./1.js"
//调用
list()
add()