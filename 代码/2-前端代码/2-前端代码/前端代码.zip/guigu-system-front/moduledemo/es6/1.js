
export function list() {
    console.log('list....')
}

export function add() {
    console.log('add....')
}