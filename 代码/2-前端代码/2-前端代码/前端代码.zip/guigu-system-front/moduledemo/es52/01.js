'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    getList: function getList() {
        console.log('获取数据列表2');
    },
    save: function save() {
        console.log('保存数据2');
    }
};